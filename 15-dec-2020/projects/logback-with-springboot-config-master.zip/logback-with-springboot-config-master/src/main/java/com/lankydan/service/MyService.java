package com.lankydan.service;

public interface MyService {
  void doStuff(String value);
}

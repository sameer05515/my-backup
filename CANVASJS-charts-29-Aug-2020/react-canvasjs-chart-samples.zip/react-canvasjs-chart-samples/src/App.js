import React, { Component } from 'react';
import Template from './views/Template';

class App extends Component {
  render() {    
    return (
		<Template/>
    );
  }
}

export default App;

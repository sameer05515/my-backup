package com.p.angular.GroceryListApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryListAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

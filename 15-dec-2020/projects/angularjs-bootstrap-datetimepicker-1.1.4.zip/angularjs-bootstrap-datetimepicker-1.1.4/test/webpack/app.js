/* globals require */

/** See the file "LICENSE" for the full license governing this code.
 *
 *
 * @author Dale "Ducky" Lotts
 * @since 9/11/16.
 */

var angular = require('angular');

angular.module('app', []);

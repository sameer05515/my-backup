
module.exports = require('./build/PatternLock');
